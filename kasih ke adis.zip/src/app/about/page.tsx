import Link from "next/link";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, ArrowRight } from "lucide-react";

export default function AboutPage() {
  return (
    <div className=" py-8">
      {/* Hero section */}
      <section className="sm:mx-40 mx-10 py-12 md:py-20 text-center">
        <h1 className="text-4xl md:text-5xl font-heading mb-6">About TextAI</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          We are on a mission to help people save time and increase productivity
          by transforming how they process information.
        </p>
      </section>

      {/* Our Story */}
      <section className=" sm:mx-40 mx-10 py-12 md:py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-heading mb-6">Our Story</h2>
            <div className="space-y-4 text-muted-foreground">
              <p>
                TextAI was founded in 2023 by a team of AI enthusiasts and
                information professionals who recognized the enormous challenge
                that information overload presents in todays world.
              </p>
              <p>
                We started with a simple idea: what if we could use the latest
                advances in artificial intelligence to help people quickly
                extract the most important information from any text?
              </p>
              <p>
                After months of research and development, we created our text
                summarization technology that preserves the most important
                information while significantly reducing reading time.
              </p>
            </div>
          </div>
          <div className="relative h-[300px] md:h-[400px] bg-muted rounded-lg overflow-hidden">
            <div className="absolute inset-0 flex items-center justify-center text-foreground/70">
              <span className="font-medium">Company Image</span>
            </div>
          </div>
        </div>
      </section>

      {/* Our Mission */}
      <section className="py-12 md:py-20 bg-muted/50">
        <div className="sm:mx-40 mx-10">
          <h2 className="text-3xl font-heading text-center mb-12">
            Our Mission
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="pt-6">
                <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-medium mb-2">Save Time</h3>
                <p className="text-muted-foreground">
                  Help people focus on what matters by reducing reading time
                  without sacrificing comprehension.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-medium mb-2">
                  Increase Understanding
                </h3>
                <p className="text-muted-foreground">
                  Make complex information more accessible by providing clear
                  and concise summaries.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-medium mb-2">Empower Knowledge</h3>
                <p className="text-muted-foreground">
                  Democratize information access by making it easier for
                  everyone to digest content quickly.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-12 md:py-20">
        <h2 className="text-3xl font-heading text-center mb-12">Our Team</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            {
              name: "Sarah Johnson",
              role: "Founder & CEO",
            },
            {
              name: "Michael Chen",
              role: "CTO",
            },
            {
              name: "Emma Rodriguez",
              role: "Head of AI Research",
            },
            {
              name: "David Kim",
              role: "Lead Developer",
            },
          ].map((member, index) => (
            <div key={index} className="flex flex-col items-center">
              <div className="w-32 h-32 bg-muted rounded-full mb-4 flex items-center justify-center text-muted-foreground">
                <span>Photo</span>
              </div>
              <h3 className="text-lg font-medium">{member.name}</h3>
              <p className="text-sm text-muted-foreground">{member.role}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Values */}
      <section className="py-12 md:py-20 bg-muted/50">
        <div className="sm:mx-40 mx-10">
          <h2 className="text-3xl font-heading text-center mb-12">
            Our Values
          </h2>
          <div className="grid md:grid-cols-2 gap-12">
            {[
              {
                title: "User-Centered",
                description:
                  "We design our products with our users' needs at the forefront of every decision.",
              },
              {
                title: "Innovation",
                description:
                  "We continuously push the boundaries of what's possible with AI technology.",
              },
              {
                title: "Transparency",
                description:
                  "We believe in being open about how our technology works and its limitations.",
              },
              {
                title: "Accessibility",
                description:
                  "We strive to make our tools available and usable for everyone.",
              },
            ].map((value, index) => (
              <div key={index} className="flex gap-4">
                <div className="rounded-full bg-primary/10 p-2 h-8 w-8 flex items-center justify-center mt-1">
                  <span className="text-primary font-medium">{index + 1}</span>
                </div>
                <div>
                  <h3 className="text-xl font-medium mb-2">{value.title}</h3>
                  <p className="text-muted-foreground">{value.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 md:py-20 text-center">
        <h2 className="text-3xl font-heading mb-6">Ready to Try BrevityAI?</h2>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
          Join thousands of professionals, students, and researchers who are
          saving time and increasing productivity with our AI text summarizer.
        </p>
        <Button size="lg" asChild>
          <Link href="/app">
            Try It For Free <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </section>
    </div>
  );
}
