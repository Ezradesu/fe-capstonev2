"use server";

const SUMMARY_API_ENDPOINT =
  "https://backend-summarize-production.up.railway.app/";

export type SummaryResult = {
  compression_ratio: string;
  methods_used: string[];
  original_length: number;
  original_text: string;
  processing_mode: string;
  question_count: number;
  questions: string[] | null;
  status: string;
  summary: string;
  summary_length: number;
  created_at: string;
};

export type SummaryRequest = {
  text: string;
  length: "short" | "medium" | "long";
  userName?: string;
  includeQuestions?: boolean;
  questionCount?: number;
};

async function callSummaryAPI(
  text: string,
  length: string,
  includeQuestions: boolean = true,
  questionCount: number = 3
) {
  const response = await fetch(`${SUMMARY_API_ENDPOINT}summarize`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "ngrok-skip-browser-warning": "true",
    },
    body: JSON.stringify({
      text: text,
      length: length,
      include_questions: includeQuestions,
      num_questions: questionCount,
    }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => null);
    throw new Error(
      `API error: ${response.status} - ${
        errorData?.error || response.statusText
      }`
    );
  }

  const result = await response.json();

  // Validate response structure
  if (!result.summary) {
    throw new Error("Invalid API response: missing summary");
  }

  return result;
}

export async function summarizeText({
  text,
  length,
  userName,
  includeQuestions = true,
  questionCount = 3,
}: SummaryRequest): Promise<SummaryResult> {
  // Input validation
  if (!text || text.trim().length === 0) {
    throw new Error("Text content is required");
  }

  const cleanText = text.trim();
  const originalWordCount = cleanText.split(/\s+/).length;

  if (originalWordCount < 10) {
    throw new Error("Text must be at least 10 words long");
  }

  if (originalWordCount > 500) {
    throw new Error("Text must be no more than 500 words long");
  }

  // Validate question count
  const validQuestionCount = Math.min(Math.max(questionCount || 3, 1), 5);

  try {
    console.log("Calling API with:", {
      textLength: cleanText.length,
      length,
      includeQuestions,
      questionCount: validQuestionCount,
    });

    const apiResult = await callSummaryAPI(
      cleanText,
      length,
      includeQuestions,
      validQuestionCount
    );

    console.log("API Response:", {
      hasSummary: !!apiResult.summary,
      questionsCount: apiResult.questions?.length || 0,
      method: apiResult.method,
    });

    // Extract and validate data from API response
    const summary = apiResult.summary || "";
    const questions = Array.isArray(apiResult.questions)
      ? apiResult.questions
      : [];

    if (!summary) {
      throw new Error("Failed to generate summary");
    }

    // Count words in summary
    const summaryWordCount = summary.trim().split(/\s+/).length;

    // Create result object
    const result: SummaryResult = {
      original_text: cleanText,
      summary: summary,
      questions: questions,
      wordCount: {
        original: originalWordCount,
        summary: summaryWordCount,
      },
      timestamp: new Date().toISOString(),
      userName: userName || "Anonymous User",
      summaryLength: length,
      questionCount: questions.length,
      processingMethod: {
        summary: apiResult.method || "Unknown",
        questions: apiResult.question_method || "Not requested",
      },
    };

    console.log("Final result:", {
      summaryLength: result.summary_length,
      questionsCount: result.question_count,
      compressionRatio: apiResult.compression_ratio,
    });

    return result;
  } catch (error) {
    console.error("Error in summarizeText:", error);

    // Enhanced error handling
    if (error instanceof Error) {
      if (error.message.includes("500")) {
        throw new Error(
          "Server temporarily unavailable. Please try again in a moment."
        );
      } else if (error.message.includes("404")) {
        throw new Error(
          "Summarization service not found. Please contact support."
        );
      } else if (
        error.message.includes("timeout") ||
        error.message.includes("TIMEOUT")
      ) {
        throw new Error(
          "Request timed out. The text might be too long or service is busy."
        );
      } else if (error.message.includes("too short")) {
        throw new Error(
          "Text is too short for processing. Please provide more content."
        );
      } else if (error.message.includes("API error")) {
        throw error; // Pass through API errors as-is
      }

      // Pass through validation errors
      if (
        error.message.includes("must be at least") ||
        error.message.includes("must be no more than") ||
        error.message.includes("is required")
      ) {
        throw error;
      }
    }

    throw new Error(
      "Failed to process text. Please check your input and try again."
    );
  }
}

// Function untuk mendapatkan history dengan fetch ke endpoint /history
export async function getSummaryHistory(): Promise<SummaryResult[]> {
  try {
    const response = await fetch(`${SUMMARY_API_ENDPOINT}history`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "ngrok-skip-browser-warning": "true",
      },
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      throw new Error(
        `Failed to fetch history: ${response.status} - ${
          errorData?.error || response.statusText
        }`
      );
    }

    const historyData = await response.json();

    // Validasi apakah response adalah array
    if (!Array.isArray(historyData)) {
      console.warn("History response is not an array:", historyData);
      return [];
    }

    // Transform data jika diperlukan sesuai dengan struktur response dari backend
    return historyData.map(transformToSummaryResult);
  } catch (error) {
    console.error("Error fetching summary history:", error);
    // Return empty array jika terjadi error, agar UI tidak crash
    return [];
  }
}

// Helper function untuk transformasi data dari API response
function transformToSummaryResult(apiRecord: any): SummaryResult {
  return {
    id: apiRecord.id || apiRecord._id,
    original: apiRecord.original || apiRecord.original_text,
    summary: apiRecord.summary || apiRecord.summary_text,
    questions: Array.isArray(apiRecord.questions)
      ? apiRecord.questions
      : typeof apiRecord.questions === "string"
      ? JSON.parse(apiRecord.questions || "[]")
      : [],
    wordCount: {
      original:
        apiRecord.word_count?.original || apiRecord.original_word_count || 0,
      summary:
        apiRecord.word_count?.summary || apiRecord.summary_word_count || 0,
    },
    timestamp:
      apiRecord.timestamp || apiRecord.created_at || new Date().toISOString(),
    userName: apiRecord.user_name || apiRecord.userName || "Anonymous User",
    summaryLength:
      apiRecord.summary_length || apiRecord.summaryLength || "medium",
    questionCount: Array.isArray(apiRecord.questions)
      ? apiRecord.questions.length
      : apiRecord.question_count || apiRecord.questionCount || 0,
    processingMethod: {
      summary:
        apiRecord.processing_method?.summary ||
        apiRecord.summary_method ||
        "Unknown",
      questions:
        apiRecord.processing_method?.questions ||
        apiRecord.question_method ||
        "Unknown",
    },
  };
}
